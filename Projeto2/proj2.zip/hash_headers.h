#define TABLE_SIZE 30323

typedef struct{
    reservation** items;
    int size;
    int count;
}hash_table_def;
